# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function
import os
import time
import shutil
import tempfile
from xml.etree import ElementTree as ET


def write_satellites(satelliteslist, src):
    try:
        root = ET.Element('satellites')
        root.text = '\n\t'

        for x in satelliteslist:
            satellite = ET.SubElement(root, 'sat', x[0])
            satellite.text = '\n\t\t'
            satellite.tail = '\n\t'

            for y in x[1]:
                # Untouched entries may use extensions unknown to this image.
                y_clean = dict((k, v) for k, v in y.items() if k != 'import')
                transponder = ET.SubElement(satellite, 'transponder', y_clean)
                transponder.tail = '\n\t\t'

            if x[1]:
                transponder.tail = '\n\t'

        if satelliteslist:
            satellite.tail = '\n'

        tree = ET.ElementTree(root)

        # Finish serialization before replacing the user's configuration.
        fd, temporary = tempfile.mkstemp(prefix='.satellites-', suffix='.xml', dir=os.path.dirname(src))
        try:
            with os.fdopen(fd, 'wb') as output:
                tree.write(output, encoding='UTF-8', xml_declaration=True)
                output.flush()
                os.fsync(output.fileno())
            if os.path.exists(src):
                shutil.copymode(src, temporary)
                backup_fd, backup = tempfile.mkstemp(
                    prefix=os.path.basename(src) + '.' + str(int(time.time())) + '.',
                    dir=os.path.dirname(src))
                os.close(backup_fd)
                shutil.copy2(src, backup)
            else:
                os.chmod(temporary, 0o644)
            os.rename(temporary, src)
        finally:
            try:
                if os.path.exists(temporary):
                    os.unlink(temporary)
            except OSError:
                pass

        return True
    except Exception as error:
        print("[SatXmlEditScreen] writeSatellites error:", str(error))
        return False
