# -*- coding: utf-8 -*-
from __future__ import absolute_import, print_function

# plugin created by iet5

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.ConfigList import ConfigListScreen
from Components.config import getConfigListEntry, config
from Components.ProgressBar import ProgressBar
from .components import apply_listbox_metrics
from .background import BackgroundTask
from enigma import eTimer

from .ui_style import modern_skin

class XMLupdateByIet5Screen(Screen, ConfigListScreen):

    skin = """    <screen name="XMLupdateByIet5Screen" position="center,center" size="1320,800"
        flags="wfNoBorder" backgroundColor="#303030">

        <!-- Buttons Background: RED / GREEN / YELLOW / BLUE (same style as other screens) -->
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/XMLupdatebyiet5/buttons/red.png"    position="40,50"   size="300,70" scale="stretch" alphatest="on" />
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/XMLupdatebyiet5/buttons/green.png"  position="360,50"  size="300,70" scale="stretch" alphatest="on" />
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/XMLupdatebyiet5/buttons/yellow.png" position="680,50"  size="300,70" scale="stretch" alphatest="on" />
        <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/XMLupdatebyiet5/buttons/blue.png"   position="1000,50" size="300,70" scale="stretch" alphatest="on" />

        <!-- Buttons -->
        <widget name="key_red"    position="40,50"   size="300,70" font="Regular;32"
            halign="center" valign="center" transparent="1" backgroundColor="#9f1313"
            foregroundColor="white" zPosition="2" />
        <widget name="key_green"  position="360,50"  size="300,70" font="Regular;32"
            halign="center" valign="center" transparent="1" backgroundColor="#1f771f"
            foregroundColor="black" zPosition="2" />
        <widget name="key_yellow" position="680,50"  size="300,70" font="Regular;32"
            halign="center" valign="center" transparent="1" backgroundColor="#a08500"
            foregroundColor="black" zPosition="2" />
        <widget name="key_blue"   position="1000,50" size="300,70" font="Regular;32"
            halign="center" valign="center" transparent="1" backgroundColor="#0033aa"
            foregroundColor="white" zPosition="2" />

        <!-- Header -->
        <widget name="title_left"  position="10,0" size="900,40"  font="Regular;32"
            halign="left" valign="center" transparent="1" foregroundColor="white" />
        <widget name="title_right" position="910,0" size="400,40" font="Regular;32"
            halign="right" valign="center" transparent="1" foregroundColor="white" />

        <!-- Source info (shown only when selecting satellites source lines) -->
        <widget name="source_info" position="10,125" size="1300,26" font="Regular;26"
            halign="center" valign="center" transparent="1" foregroundColor="white" />

        <!-- Divider -->
        <ePixmap pixmap="skin_default/div-h.png" position="10,150" size="1300,2" />

        <!-- Config area -->
        <widget name="config" position="10,155" size="1300,440"
            enableWrapAround="1" scrollbarMode="showOnDemand" />

        <!-- Helper -->
        <widget name="helper" position="10,605" size="1300,70" font="Regular;26"
            halign="left" valign="top" foregroundColor="white" />

        <!-- Progress -->
        <widget name="progress" position="10,680" size="1300,45"
            pixmap="/usr/lib/enigma2/python/Plugins/Extensions/XMLupdatebyiet5/buttons/progress_bar.png"
            transparent="1" borderWidth="2" borderColor="#707070" foregroundColor="#00C800" zPosition="1" />

        <widget name="progress_text" position="10,680" size="1300,45" font="Regular;32"
            halign="center" valign="center" transparent="1" foregroundColor="yellow" zPosition="2" />

        <!-- Footer -->
        <widget name="footer" position="10,730" size="1300,60" font="Regular;26"
            halign="center" valign="center" foregroundColor="#FFD700" />
    </screen>"""
    skin = modern_skin(skin)

    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self._closed = False
        self._source_task = None
        self._source_key = None
        self._source_results = {}
        self._download_task = None
        self.onClose.append(self._cleanup)

        # import runtime helpers from plugin.py (avoid circular import at top)
        from . import plugin as core
        self.core = core

        self._last_download_ok = False

        self["title_left"] = Label("XMLupdate by iet5")
        self["title_right"] = Label(self.core.read_version())

        # Buttons order requested:
        # Red = Exit/Cancel (left)
        # Green = Save
        # Yellow = Satellite.xml Edit
        # Blue = Download
        self["key_red"] = Label("Exit")
        self["key_green"] = Label("Save")
        self["key_yellow"] = Label("Satellite.xml Edit")
        self["key_blue"] = Label("Download")

        self["footer"] = Label("Ready.")
        self["helper"] = Label("")

        self["source_info"] = Label("")

        self["progress"] = ProgressBar()
        self["progress"].setValue(0)
        self["progress_text"] = Label("0%")

        ConfigListScreen.__init__(self, [], session=session)
        self.build_list()
        self.onLayoutFinish.append(self._apply_config_list_metrics)

        # initialize source info label
        self._on_config_selection_changed()

        self._setup_source_notifiers()
        self._sync_source_enabled_state()
        try:
            self["config"].onSelectionChanged.append(self._on_config_selection_changed)
        except Exception:
            pass

        self["actions"] = ActionMap(
            ["ColorActions", "OkCancelActions"],
            {
                "red": self.close,
                "green": self.save_settings,
                "yellow": self.open_sat_editor,
                "blue": self.do_download,
                "cancel": self.close,
            },
            -1
        )

    def _apply_config_list_metrics(self):
        try:
            from enigma import gFont
            apply_listbox_metrics(
                self["config"],
                item_height=55,
                fonts=[(0, gFont("Regular", 32))]
            )
        except Exception:
            pass

    def build_list(self):
        p = config.plugins.XMLupdatebyiet5
        lst = []
        lst.append(getConfigListEntry("Save mode", p.save_mode))
        if p.save_mode.value == "custom":
            lst.append(getConfigListEntry("Path where to save", p.custom_path))

        lst.append(getConfigListEntry("Download + backup satellites.xml", p.do_sat))
        lst.append(getConfigListEntry("Download + backup terrestrial.xml", p.do_ter))
        lst.append(getConfigListEntry("Download + backup cables.xml", p.do_cab))
        lst.append(getConfigListEntry("Restart GUI after update", p.restart_gui_after_update))

        # satellites.xml source (only one can be enabled at a time)
        lst.append(getConfigListEntry("Download satellites.xml from OE-Alliance", p.sat_src_oe_alliance))
        lst.append(getConfigListEntry("Download satellites.xml from OpenPLi", p.sat_src_openpli))

        self["config"].list = lst

    
    # Compatibility: some images do not fire config.onSelectionChanged reliably
    # so we also hook into ConfigListScreen.selectionChanged().
    def selectionChanged(self):
        try:
            ConfigListScreen.selectionChanged(self)
        except Exception:
            pass
        self._on_config_selection_changed()


    def _sync_source_enabled_state(self):
        p = config.plugins.XMLupdatebyiet5
        try:
            if p.sat_src_oe_alliance.value:
                try:
                    p.sat_src_openpli.setEnabled(False)
                except Exception:
                    pass
            else:
                try:
                    p.sat_src_openpli.setEnabled(True)
                except Exception:
                    pass

            if p.sat_src_openpli.value:
                try:
                    p.sat_src_oe_alliance.setEnabled(False)
                except Exception:
                    pass
            else:
                try:
                    p.sat_src_oe_alliance.setEnabled(True)
                except Exception:
                    pass
        except Exception:
            pass

# ---------- satellites.xml source handling ----------
    def _setup_source_notifiers(self):
        p = config.plugins.XMLupdatebyiet5
        try:
            p.sat_src_oe_alliance.addNotifier(self._on_sat_source_oe_changed, initial_call=False)
        except Exception:
            pass
        try:
            p.sat_src_openpli.addNotifier(self._on_sat_source_openpli_changed, initial_call=False)
        except Exception:
            pass

    def _on_sat_source_oe_changed(self, *args, **kwargs):
        p = config.plugins.XMLupdatebyiet5
        try:
            if p.sat_src_oe_alliance.value:
                # If OE-Alliance is enabled, force OpenPLi off
                p.sat_src_openpli.value = False
                p.sat_src_openpli.save()

            # Enable/disable the other source (mutual exclusive)
            try:
                if p.sat_src_oe_alliance.value:
                    p.sat_src_openpli.setEnabled(False)
                else:
                    p.sat_src_openpli.setEnabled(True)
            except Exception:
                pass
        except Exception:
            pass

        self._on_config_selection_changed()
    def _on_sat_source_openpli_changed(self, *args, **kwargs):
        p = config.plugins.XMLupdatebyiet5
        try:
            if p.sat_src_openpli.value:
                # If OpenPLi is enabled, force OE-Alliance off
                p.sat_src_oe_alliance.value = False
                p.sat_src_oe_alliance.save()

            # Enable/disable the other source (mutual exclusive)
            try:
                if p.sat_src_openpli.value:
                    p.sat_src_oe_alliance.setEnabled(False)
                else:
                    p.sat_src_oe_alliance.setEnabled(True)
            except Exception:
                pass
        except Exception:
            pass

        self._on_config_selection_changed()

    def _on_config_selection_changed(self, *args, **kwargs):
        """Show commits info when satellites source lines are selected.

        This is shown immediately on selection (even if the option is currently set to No),
        and cleared when leaving the source lines.
        """
        if self._closed:
            return
        self._source_key = None
        try:
            cur = self["config"].getCurrent()
        except Exception:
            cur = None

        # Default: clear helper when not on the source lines
        try:
            self["helper"].setText("")
        except Exception:
            pass
        try:
            self["source_info"].setText("")
        except Exception:
            pass

        if not cur or len(cur) < 2:
            return

        title = cur[0]

        src_key = ""
        src_label = ""
        if title == "Download satellites.xml from OE-Alliance":
            src_key = "oe_alliance"
            src_label = "OE-Alliance"
        elif title == "Download satellites.xml from OpenPLi":
            src_key = "openpli"
            src_label = "OpenPLi"
        else:
            return

        self._source_key = src_key
        if src_key in self._source_results:
            self._show_source_lines(self._source_results[src_key])
            return
        if self._source_task is not None:
            return
        self["helper"].setText("Loading source information...")
        core = self.core

        def operation(emit):
            return core.get_satellites_commits_lines(src_key, per_page=1, force_refresh=False)

        def finished(lines):
            self._source_task = None
            self._source_results[src_key] = lines or ["Source information unavailable for %s" % src_label]
            if not self._closed:
                self._on_config_selection_changed()

        def failed(error):
            finished(["Source information unavailable for %s" % src_label])

        try:
            self._source_task = BackgroundTask(eTimer, operation, finished, failed)
            self._source_task.start()
        except Exception as error:
            if self._source_task is not None:
                self._source_task.close()
            self._source_task = None
            self["helper"].setText("Source information unavailable.")

    def _show_source_lines(self, lines):
        text = "\n".join(lines)
        try:
            if isinstance(text, unicode):
                text = text.encode("utf-8", "ignore")
        except NameError:
            pass
        self["helper"].setText(text)

    def _cleanup(self):
        self._closed = True
        for task in (self._source_task, self._download_task):
            if task is not None:
                task.close()
        self._source_task = self._download_task = None
        p = config.plugins.XMLupdatebyiet5
        for element, callback in ((p.sat_src_oe_alliance, self._on_sat_source_oe_changed),
                                  (p.sat_src_openpli, self._on_sat_source_openpli_changed)):
            try:
                element.removeNotifier(callback)
            except (AttributeError, ValueError):
                pass
        try:
            self["config"].onSelectionChanged.remove(self._on_config_selection_changed)
        except (AttributeError, ValueError):
            pass

    # ---------- YELLOW: open satellites.xml editor ----------
    def open_sat_editor(self):
        if self.core.is_download_active():
            self["footer"].setText("Wait for the current XML update to finish.")
            return
        try:
            from .satxmleditscreen import SatXmlEditScreen
            self.session.openWithCallback(lambda *args, **kwargs: None, SatXmlEditScreen)
        except Exception as e:
            # self.session.open(MessageBox, "Failed to open Satellite.xml Editor.\n%s" % str(e), MessageBox.TYPE_ERROR)
            try:
                from Tools import Notifications
                Notifications.AddNotification(
                    MessageBox,
                    "Failed to open Satellite.xml Editor.\n%s" % str(e),
                    MessageBox.TYPE_ERROR
                )
            except Exception:
                try:
                    print("Failed to open Satellite.xml Editor: %s" % str(e))
                except Exception:
                    pass

    # ---------- Save only (GREEN) ----------
    def save_settings(self):
        try:
            config.plugins.XMLupdatebyiet5.save()
            config.save()
            self["footer"].setText("Settings saved.")
            self.core.log_line("Settings saved.")
            self.session.open(MessageBox, "Settings saved successfully.", MessageBox.TYPE_INFO)
        except Exception as e:
            self["footer"].setText("Failed to save settings.")
            self.core.log_line("Failed to save settings: %s" % str(e))
            self.session.open(MessageBox, "Failed to save settings.", MessageBox.TYPE_ERROR)

    # ---------- Restart confirmation ----------
    def _ask_restart_gui(self):
        if not self.core.can_restart_gui():
            self.session.open(MessageBox, "Restart GUI is not supported on this image.", MessageBox.TYPE_ERROR)
            return

        self.session.openWithCallback(
            self._on_restart_answer,
            MessageBox,
            "Restart GUI now?",
            MessageBox.TYPE_YESNO
        )

    def _on_restart_answer(self, answer):
        if answer:
            self.core.log_line("Restart GUI confirmed by user.")
            self.core.do_restart_gui(self.session)
        else:
            self.core.log_line("Restart GUI cancelled by user.")
            self["footer"].setText("Restart cancelled.")

    # ---------- Result popup then restart ----------
    def _show_download_result_then_restart(self, result):
        self._last_download_ok = bool(result.get("all_ok", False))

        downloaded_files = int(result.get("downloaded_files", 0))
        ok_copies = int(result.get("ok_copies", 0))
        fail_copies = int(result.get("fail_copies", 0))
        targets = result.get("targets", []) or []
        targets_txt = ", ".join(targets)
        
        self["progress"].setValue(100)
        self["progress_text"].setText("100%")

        sat_src = ""
        try:
            if "satellites.xml" in self.core.get_selected_files():
                sat_src = self.core.get_satellites_source_label()
        except Exception:
            sat_src = ""

        if self._last_download_ok:
            self["footer"].setText("Download completed successfully.")
            msg = (
                "Download completed successfully.\n"
                "Downloaded files: %d\n"
                "Saved copies: %d\n"
                "Failed copies: %d\n"
                "Saved to: %s\n"
                "Downloaded from site: %s"
            ) % (downloaded_files, ok_copies, fail_copies, targets_txt, sat_src or "N/A")
            mtype = MessageBox.TYPE_INFO
        else:
            self["footer"].setText("Download completed with errors.")
            msg = (
                "Download completed with errors.\n"
                "Downloaded files: %d\n"
                "Saved copies: %d\n"
                "Failed copies: %d\n"
                "Saved to: %s\n"
                "Log: %s\n"
                "Downloaded from site: %s"
            ) % (downloaded_files, ok_copies, fail_copies, targets_txt, self.core.LOG_FILE, sat_src or "N/A")
            mtype = MessageBox.TYPE_WARNING

        # show for 2 seconds then ask restart (if enabled and all ok)
        self.session.openWithCallback(
            self._after_result_popup,
            MessageBox,
            msg,
            mtype,
            timeout=0
        )

    def _after_result_popup(self, *args, **kwargs):
        if self._last_download_ok and config.plugins.XMLupdatebyiet5.restart_gui_after_update.value:
            self._ask_restart_gui()

    # ---------- Download only (BLUE) ----------
    def do_download(self):
        if self._closed:
            return
        if self._download_task is not None or self.core.is_download_active():
            self["footer"].setText("An XML update is already running.")
            return
        files = list(self.core.get_selected_files())
        if not files:
            self.session.open(MessageBox, "Nothing selected to download.", MessageBox.TYPE_INFO)
            return
        # Snapshot configuration on the GUI thread before starting I/O.
        core = self.core
        targets = list(core.get_target_paths())
        satellite_url = core.get_satellites_url()
        self["footer"].setText("Starting download... You can close this screen; the update will continue.")
        self["progress"].setValue(0)
        self["progress_text"].setText("0%")

        def operation(emit):
            return core.run_download(
                progress_cb=lambda pct: emit('progress', pct),
                status_cb=lambda text: emit('status', text),
                files=files, targets=targets, satellite_url=satellite_url)

        def event(kind, value):
            if kind == 'progress':
                pct = max(0, min(100, int(value)))
                self["progress"].setValue(pct)
                self["progress_text"].setText("%d%%" % pct)
            elif kind == 'status':
                self["footer"].setText(value)

        def finished(result):
            self._download_task = None
            if not self._closed:
                self._show_download_result_then_restart(result)

        def failed(error):
            self._download_task = None
            if not self._closed:
                self["footer"].setText("Download failed.")
                self.session.open(MessageBox, "Download failed: %s" % error, MessageBox.TYPE_ERROR)

        try:
            self._download_task = BackgroundTask(eTimer, operation, finished, failed, event)
            self._download_task.start()
        except Exception as error:
            if self._download_task is not None:
                self._download_task.close()
            failed(str(error))
