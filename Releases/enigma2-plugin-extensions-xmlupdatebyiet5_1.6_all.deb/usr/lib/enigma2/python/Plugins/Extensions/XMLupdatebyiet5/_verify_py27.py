# -*- coding: utf-8 -*-
from __future__ import print_function
import os, sys, types, traceback
sys.dont_write_bytecode = True
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(ROOT))
PACKAGE = os.path.basename(ROOT)

class Node(object):
    def __init__(self, value=False, **kw): self.value=value
    def __getattr__(self, key):
        node=Node(); setattr(self,key,node); return node
    def __call__(self,*a,**k): return None

class Content(object):
    def __init__(self): self.rows=[]; self.index=0
    def setList(self,rows): self.rows=rows; self.index=min(self.index,max(0,len(rows)-1))
    def getCurrentSelection(self): return self.rows[self.index] if self.rows else None
    def getCurrentSelectionIndex(self): return self.index if self.rows else None
    def setSelectionClip(self,*a): pass
    def setItemHeight(self,*a): pass
    def setFont(self,*a): pass

class Widget(object):
    def __init__(self,text='',*a,**kw): self.setText(text); self.l=Content(); self.instance=None; self.onSelectionChanged=[]
    def setText(self,text):
        if not isinstance(text,str): raise TypeError('native label requires str, got '+type(text).__name__)
        self.text=text
    def hide(self): pass
    def show(self): pass
    def getSelectionIndex(self): return self.l.getCurrentSelectionIndex()
    def moveToIndex(self,index): self.l.index=index
    def getCurrent(self): return self.l.getCurrentSelection()
    def up(self): self.l.index=(self.l.index-1)%len(self.l.rows) if self.l.rows else 0
    def down(self): self.l.index=(self.l.index+1)%len(self.l.rows) if self.l.rows else 0
    pageUp=up; pageDown=down

class MenuList(Widget):
    def __init__(self,entries=None,*a,**kw): Widget.__init__(self); self.l.setList(entries or [])

class Screen(dict):
    def __init__(self,session):
        dict.__init__(self); self.session=session; self.onClose=[]; self.onLayoutFinish=[]; self.closed=False
    def setTitle(self,text): Widget().setText(text); self.title=text
    def close(self,*a): self.closed=True

class Timer(object):
    def __init__(self): self.callback=[]
    def start(self,*a): pass
    def stop(self): pass

class ConfigListScreen(object):
    def __init__(self,entries,*a,**kw): self['config']=MenuList(entries)

class Config(Node):
    def __init__(self,*a,**kw): Node.__init__(self,kw.get('default',a[0] if a else False))
    def setUseableChars(self,chars): pass

class GUIComponent(object): pass
class HTMLComponent(object): pass
class Session(object):
    def open(self,*a,**kw): print('MESSAGE',repr(a))
    def openWithCallback(self,callback,cls,*args,**kw): return cls(self,*args)

class ActionMap(object):
    def __init__(self,contexts,actions,*a): self.actions=actions
    def setEnabled(self,value): self.enabled=value

class MessageBox(object): TYPE_INFO=0; TYPE_ERROR=1; TYPE_YESNO=2

def module(name,**items):
    obj=types.ModuleType(name); obj.__dict__.update(items); sys.modules[name]=obj; return obj
for name in ('Screens','Components','Tools'): module(name)
module('Screens.Screen',Screen=Screen)
module('Screens.MessageBox',MessageBox=MessageBox)
for name in ('ChoiceBox','Console'):
 module('Screens.'+name,**{name:Widget})
for name in ('Button','Label','Pixmap','ProgressBar'):
 module('Components.'+name,**{name:Widget})
module('Components.ActionMap',ActionMap=ActionMap)
module('Components.MenuList',MenuList=MenuList)
module('Components.GUIComponent',GUIComponent=GUIComponent)
module('Components.HTMLComponent',HTMLComponent=HTMLComponent)
module('Components.ConfigList',ConfigListScreen=ConfigListScreen)
config=Node(); config.misc.tssateditorT2MI=Node(False)
config.plugins.XMLupdatebyiet5.appearance=Node('dark')
conf=module('Components.config',config=config,getConfigListEntry=lambda *args:args)
for name in ('ConfigYesNo','ConfigFloat','ConfigInteger','ConfigSelection','ConfigText','ConfigSelectionNumber'):
 setattr(conf,name,Config)
module('Components.NimManager',nimmanager=Node())
module('Tools.Directories',fileExists=lambda path: True)
module('Tools.Notifications',AddNotification=lambda *a,**kw: print('NOTIFICATION',repr(a)))
module('Tools.LoadPixmap',LoadPixmap=lambda **kw:None)

def entry(pos,size,text='',**kw):
    if not isinstance(text,str): raise TypeError('native MultiContent requires str, got '+type(text).__name__)
    return (0,pos[0],pos[1],size[0],size[1],kw.get('font',0),kw.get('flags',0),text)
module('Components.MultiContent',MultiContentEntryText=entry)
module('enigma',eListboxPythonMultiContent=Content,eListbox=Widget,gFont=lambda family,size:(family,size),
       eRect=lambda *a:a,eTimer=Timer,RT_HALIGN_LEFT=1,RT_HALIGN_RIGHT=2,RT_HALIGN_CENTER=4,
       RT_VALIGN_CENTER=8,RT_VALIGN_TOP=16,getDesktop=lambda *a:Node())
# Desktop geometry must be a number, not a dynamic config placeholder.
sys.modules['enigma'].getDesktop=lambda *a:types.SimpleNamespace() if False else Desktop()
class Desktop(object):
 def size(self): return self
 def height(self): return 1080
# Read a real UTF-8 fixture through the actual production parser.
fixture=os.path.join(ROOT,'_verify_satellites.xml')
with open(fixture,'wb') as output:
 output.write(u'<satellites><sat name="\u0642\u0645\u0631" position="130" flags="1"><transponder frequency="11000000" symbol_rate="27500000" polarization="0" system="0" /></sat><sat name="Other" position="192" flags="1" /></satellites>'.encode('utf8'))
try:
 mod=__import__(PACKAGE+'.satxmleditscreen',fromlist=['SatXmlEditScreen'])
 original=mod.SatXmlEditScreen.readSatellites
 mod.SatXmlEditScreen.readSatellites=lambda self,path,stop=True:original(self,fixture,stop)
 screen=mod.SatXmlEditScreen(Session())
 assert not getattr(screen,'_init_fail_timer',None),'Screen initialization failed: inspect printed error or log'
 for callback in screen.onLayoutFinish: callback()
 assert not screen.closed
 screen.toggleChecked(); screen.toggleAllChecked(); screen.toggleAllChecked()
 print('PASS satellites initialization, layout and checkboxes on',sys.version.split()[0])
 from importlib import import_module
 tp=import_module(PACKAGE+'.transponderseditor').TranspondersEditor(Session(),screen.satelliteslist[0])
 for callback in tp.onLayoutFinish: callback()
 tp.toggleChecked(); tp.toggleAllChecked(); tp.toggleAllChecked()
 print('PASS transponders initialization, layout and checkboxes')
 sat=import_module(PACKAGE+'.sateditscreen').SatEditor(Session(),screen.satelliteslist)
 for callback in sat.onLayoutFinish: callback()
 print('PASS Add satellite initialization and layout')
except Exception:
 traceback.print_exc(); sys.exit(1)
finally:
 os.unlink(fixture)
