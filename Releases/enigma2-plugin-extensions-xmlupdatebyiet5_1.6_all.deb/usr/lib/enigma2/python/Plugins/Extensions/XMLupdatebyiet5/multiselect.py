# -*- coding: utf-8 -*-
"""Checkboxes use live object identity, never XML values or row numbers."""
from __future__ import absolute_import


class CheckedEntries(object):
    def __init__(self):
        self.entries = []
        self.checked = {}  # Strong references prevent object id reuse.

    def sync(self, entries):
        self.entries = list(entries)
        live = set(id(entry) for entry in entries)
        self.checked = dict((key, value) for key, value in self.checked.items() if key in live)

    def selected(self):
        return [entry for entry in self.entries if id(entry) in self.checked]

    def toggle(self, entry):
        key = id(entry)
        if key in self.checked:
            del self.checked[key]
        else:
            self.checked[key] = entry

    def toggle_all(self):
        if self.entries and len(self.checked) == len(self.entries):
            self.checked.clear()
        else:
            self.checked = dict((id(entry), entry) for entry in self.entries)

    def replace(self, old, new):
        if id(old) in self.checked:
            del self.checked[id(old)]
            self.checked[id(new)] = new


class MultiSelectScreen(object):
    def initMultiSelect(self, attribute):
        from Components.ActionMap import ActionMap
        from Components.Button import Button
        self._selection_attribute = attribute
        self['key_selection'] = Button('')
        self['selection_actions'] = ActionMap(['XMLCheckboxActions'], {
            'toggleChecked': self.toggleChecked,
            'toggleAllChecked': self.toggleAllChecked}, -2)
        self['list'].checkedChanged = self.updateCheckedLabel
        self.updateCheckedLabel()

    def updateCheckedLabel(self):
        from . import _
        from .components import safe_text
        state = self['list'].checks
        action = _('Deselect All') if state.entries and len(state.checked) == len(state.entries) else _('Select All')
        self['key_selection'].setText(safe_text(
            _('0: Mark / Unmark | 5: %s | Selected: %d/%d') %
            (action, len(state.checked), len(state.entries))))

    def _refreshChecked(self):
        self['list'].setEntries(getattr(self, self._selection_attribute))
        self.updateSelection()

    def toggleChecked(self):
        entries = getattr(self, self._selection_attribute)
        index = self['list'].getSelectedIndex()
        if index is not None and 0 <= index < len(entries):
            self['list'].checks.toggle(entries[index])
            self._refreshChecked()

    def toggleAllChecked(self):
        self['list'].checks.toggle_all()
        self._refreshChecked()
