# -*- coding: utf-8 -*-
"""Run blocking I/O off the GUI thread; deliver results only from eTimer."""
from __future__ import absolute_import
import threading
try:
    from queue import Queue, Empty, Full
except ImportError:
    from Queue import Queue, Empty, Full


def connect_timer(timer, callback):
    """Retain the returned connection on images using eSignal.connect."""
    try:
        timer.callback.append(callback)
    except AttributeError:
        try:
            timer.timeout.get().append(callback)
        except AttributeError:
            return timer.timeout.connect(callback)
    return None


def stop_timer(timer):
    try:
        timer.stop()
    except Exception:
        pass
    try:
        del timer.callback[:]
    except AttributeError:
        try:
            del timer.timeout.get()[:]
        except AttributeError:
            pass


class BackgroundTask(object):
    def __init__(self, timer_factory, operation, finished, failed, event=None):
        self._finished = finished
        self._failed = failed
        self._event = event
        self._events = Queue(32)
        self._done = threading.Event()
        self._closed = threading.Event()
        self._result = None
        self._error = None
        self._timer = timer_factory()
        self._connection = connect_timer(self._timer, self.poll)

        # The worker does not call widgets, Screen.close, or Enigma2 APIs.
        def work():
            try:
                self._result = operation(self.emit)
            except Exception as error:
                self._error = str(error)
            finally:
                self._done.set()

        self._thread = threading.Thread(target=work)
        self._thread.daemon = True

    def start(self):
        # If timer/thread startup fails the caller can report it safely.
        try:
            self._timer.start(100, False)
            self._thread.start()
        except Exception:
            self.close()
            raise

    def emit(self, kind, value):
        if self._closed.is_set():
            return
        try:
            self._events.put_nowait((kind, value))
        except Full:
            # Progress is optional; never block a download on GUI consumption.
            pass

    def poll(self):
        if self._closed.is_set():
            return
        for unused in range(32):
            try:
                kind, value = self._events.get_nowait()
            except Empty:
                break
            if self._event is not None:
                self._event(kind, value)
            if self._closed.is_set():
                return
        if self._done.is_set() and self._events.empty():
            callback = self._failed if self._error is not None else self._finished
            value = self._error if self._error is not None else self._result
            self.close()
            if callback is not None:
                callback(value)

    def close(self):
        self._closed.set()
        stop_timer(self._timer)
        self._connection = None
        self._finished = self._failed = self._event = None
