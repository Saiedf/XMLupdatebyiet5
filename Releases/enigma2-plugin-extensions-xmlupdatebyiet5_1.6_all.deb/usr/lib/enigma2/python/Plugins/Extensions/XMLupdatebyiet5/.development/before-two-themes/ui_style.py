# -*- coding: utf-8 -*-
"""Native, skin-aware button styling. No images, timers or external assets."""
from __future__ import absolute_import
import sys
from xml.etree import ElementTree as ET

try:
    import skin as active_skin
except ImportError:
    active_skin = None

KEYS = ('red', 'green', 'yellow', 'blue')
FALLBACKS = ('#9f1313', '#1f771f', '#a08500', '#18188b')


def key_color(index):
    name = 'key_' + KEYS[index]
    colors = getattr(active_skin, 'colors', {})
    return name if name in colors else FALLBACKS[index]


def modern_skin(source):
    """Keep content geometry and native window/text colors of the user's skin."""
    root = ET.fromstring(source)
    # Inherit the active window style, including light skins.
    root.attrib.pop('backgroundColor', None)
    widgets = dict((item.get('name'), item) for item in root.findall('widget'))
    buttons = [(index, widgets['key_' + name]) for index, name in enumerate(KEYS)
               if 'key_' + name in widgets]
    if not buttons:
        return source
    old_y = min(int(widget.get('position').split(',')[1]) for index, widget in buttons)
    top = 52 if old_y >= 40 else 12
    family = 'Regular'
    fonts = getattr(active_skin, 'fonts', {})
    font = fonts.get('Button', fonts.get('Body'))
    if isinstance(font, (tuple, list)) and font and isinstance(font[0], type('')):
        family = font[0]

    for item in list(root):
        # Replace bitmap capsules with lightweight native outlines.
        path = item.get('pixmap', '').replace('\\', '/')
        if item.tag == 'ePixmap' and any(path.endswith('/buttons/' + key + '.png') for key in KEYS):
            root.remove(item)
        elif item.tag == 'widget' and item.get('name') not in ('key_menu', 'progress'):
            # Let text and panels follow the active skin instead of forcing white/black.
            for attribute in ('backgroundColor', 'foregroundColor'):
                item.attrib.pop(attribute, None)

    for index, widget in buttons:
        x = 20 + index * 325
        color = key_color(index)
        # Native one-pixel strips: eLabel.borderWidth outlines text on some images.
        for edge_x, edge_y, width, height in (
                (x, top, 305, 1), (x, top + 53, 305, 1),
                (x, top, 1, 54), (x + 304, top, 1, 54)):
            ET.SubElement(root, 'eLabel', {
                'position': '%d,%d' % (edge_x, edge_y),
                'size': '%d,%d' % (width, height),
                'backgroundColor': color, 'zPosition': '0'})
        ET.SubElement(root, 'eLabel', {
            'position': '%d,%d' % (x + 8, top + 13), 'size': '4,28',
            'backgroundColor': color, 'zPosition': '2'})
        widget.attrib.update({
            'position': '%d,%d' % (x + 18, top), 'size': '269,54',
            'font': '%s;26' % family, 'halign': 'center', 'valign': 'center',
            'transparent': '1', 'zPosition': '1'})

    menu = widgets.get('key_menu')
    if menu is not None:
        menu.attrib.update({'position': '1266,%d' % (top + 18),
                           'size': '24,18', 'zPosition': '3'})
    progress = widgets.get('progress')
    if progress is not None:
        progress.attrib.pop('pixmap', None)
        progress.attrib.update({'foregroundColor': key_color(1),
                               'borderColor': key_color(3), 'borderWidth': '1'})
    for item in list(root):
        if item.tag == 'ePixmap' and item.get('pixmap') == 'skin_default/div-h.png':
            item.tag = 'eLabel'
            item.attrib.pop('pixmap', None)
            item.set('backgroundColor', key_color(3))
    result = ET.tostring(root, encoding='UTF-8')
    return result.decode('UTF-8') if sys.version_info[0] >= 3 else result
