# -*- coding: utf-8 -*-
"""Native, skin-aware button styling. No images, timers or external assets."""
from __future__ import absolute_import
import sys
from xml.etree import ElementTree as ET

try:
    import skin as active_skin
except ImportError:
    active_skin = None

KEYS = ('red', 'green', 'yellow', 'blue')
FALLBACKS = ('#9f1313', '#1f771f', '#a08500', '#18188b')
FRAME = 15
FRAME_COLOR = '#D0D0D0'
THEMES = {
    'dark': {'background': '#1B1B1B', 'text': '#F3F5F7',
             'panel': '#252A32', 'selected': '#354B64',
             'selected_text': '#FFFFFF', 'border': '#536172'},
    'light': {'background': '#F3F5F8', 'text': '#172638',
              'panel': '#FFFFFF', 'selected': '#D6E7FA',
              'selected_text': '#102B47', 'border': '#A7B2BF'}}


def get_theme():
    try:
        from Components.config import config
        value = config.plugins.XMLupdatebyiet5.appearance.value
        return value if value in THEMES else 'dark'
    except (AttributeError, KeyError):
        # Older Enigma2 ConfigSubsection implementations raise KeyError for
        # missing entries while plugin.py is still importing its screens.
        return 'dark'


def palette(theme=None):
    return THEMES.get(theme or get_theme(), THEMES['dark'])


def theme_color(name):
    return int(palette()[name][1:], 16)


def button_palette(index):
    color = key_color(index)
    value = getattr(active_skin, 'colors', {}).get(color, color)
    try:
        if hasattr(value, 'argb'):
            rgb = int(value.argb()) & 0xFFFFFF
        elif isinstance(value, int):
            rgb = value & 0xFFFFFF
        else:
            rgb = int(value.lstrip('#'), 16) & 0xFFFFFF
    except (ValueError, TypeError, AttributeError):
        rgb = int(FALLBACKS[index][1:], 16)
    # Pick the higher-contrast text color, including custom skin key colors.
    channels = [((rgb >> shift) & 255) / 255.0 for shift in (16, 8, 0)]
    linear = [c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4 for c in channels]
    lightness = sum(c * weight for c, weight in zip(linear, (0.2126, 0.7152, 0.0722)))
    foreground = '#000000' if (lightness + 0.05) / 0.05 >= 1.05 / (lightness + 0.05) else '#FFFFFF'
    return '#%06X' % rgb, foreground


def key_color(index):
    name = 'key_' + KEYS[index]
    colors = getattr(active_skin, 'colors', {})
    return name if name in colors else FALLBACKS[index]


def modern_skin(source, theme=None):
    """Build a fresh native layout from the original, unpadded screen XML."""
    root = ET.fromstring(source)
    colors = palette(theme)
    root.set('backgroundColor', colors['background'])
    widgets = dict((item.get('name'), item) for item in root.findall('widget'))
    buttons = [(index, widgets['key_' + name]) for index, name in enumerate(KEYS)
               if 'key_' + name in widgets]
    old_y = min([int(widget.get('position').split(',')[1]) for index, widget in buttons] or [0])
    top = 52 if old_y >= 40 else 12
    family = 'Regular'
    fonts = getattr(active_skin, 'fonts', {})
    font = fonts.get('Button', fonts.get('Body'))
    if isinstance(font, (tuple, list)) and font and isinstance(font[0], type('')):
        family = font[0]

    for item in list(root):
        path = item.get('pixmap', '').replace('\\', '/')
        if item.tag == 'ePixmap' and any(path.endswith('/buttons/' + key + '.png') for key in KEYS):
            root.remove(item)
        elif item.tag == 'widget' and item.get('name') not in ('key_menu', 'progress'):
            item.set('foregroundColor', colors['text'])
            item.set('backgroundColor', colors['background'])
            if item.get('name') in ('config', 'list', 'head', 'bandlist', 'infolist', 'polhead'):
                item.set('backgroundColor', colors['panel'])
                item.set('backgroundColorSelected', colors['selected'])
                item.set('foregroundColorSelected', colors['selected_text'])

    for index, widget in buttons:
        x = 20 + index * 325
        fill, foreground = button_palette(index)
        widget.attrib.update({
            'position': '%d,%d' % (x, top), 'size': '305,54',
            'font': '%s;28' % family, 'halign': 'center', 'valign': 'center',
            'backgroundColor': fill, 'foregroundColor': foreground,
            'transparent': '0', 'zPosition': '1'})

    menu = widgets.get('key_menu')
    if menu is not None:
        menu.attrib.update({'position': '1266,%d' % (top + 18),
                           'size': '24,18', 'zPosition': '3'})
    progress = widgets.get('progress')
    if progress is not None:
        progress.attrib.pop('pixmap', None)
        progress.attrib.update({'foregroundColor': button_palette(1)[0],
                               'backgroundColor': colors['panel'],
                               'borderColor': colors['border'], 'borderWidth': '1'})
    for item in list(root):
        if item.tag == 'ePixmap' and item.get('pixmap') == 'skin_default/div-h.png':
            item.tag = 'eLabel'
            item.attrib.pop('pixmap', None)
            item.set('backgroundColor', colors['border'])
        elif item.tag == 'eLabel':
            item.set('backgroundColor', colors['border'])
        position = item.get('position')
        if position:
            x, y = [int(value) for value in position.split(',')]
            item.set('position', '%d,%d' % (x + FRAME, y + FRAME))

    width, height = [int(value) + FRAME * 2 for value in root.get('size').split(',')]
    root.set('size', '%d,%d' % (width, height))
    # Four native rectangles form the border, outside all original content.
    for x, y, w, h in ((0, 0, width, FRAME), (0, height - FRAME, width, FRAME),
                       (0, FRAME, FRAME, height - FRAME * 2),
                       (width - FRAME, FRAME, FRAME, height - FRAME * 2)):
        ET.SubElement(root, 'eLabel', {'position': '%d,%d' % (x, y),
            'size': '%d,%d' % (w, h), 'backgroundColor': FRAME_COLOR, 'zPosition': '10'})
    result = ET.tostring(root, encoding='UTF-8')
    return result.decode('UTF-8') if sys.version_info[0] >= 3 else result


def apply_theme(screen, theme=None):
    """Recolor the open main screen in place; never reopen modals or stop work."""
    from enigma import gRGB
    colors = palette(theme)
    def set_color(target, method, value):
        setter = getattr(target, method, None)
        if setter is not None:
            setter(gRGB(int(value[1:], 16)))
    set_color(getattr(screen, 'instance', None), 'setBackgroundColor', colors['background'])
    for name, widget in screen.items():
        target = getattr(widget, 'instance', None)
        if target is None or name == 'key_menu':
            continue
        if name in ['key_' + key for key in KEYS]:
            fill, foreground = button_palette(KEYS.index(name[4:]))
            set_color(target, 'setBackgroundColor', fill)
            set_color(target, 'setForegroundColor', foreground)
        elif name == 'progress':
            set_color(target, 'setBackgroundColor', colors['panel'])
            set_color(target, 'setForegroundColor', button_palette(1)[0])
        else:
            is_list = name in ('config', 'list', 'head', 'bandlist', 'infolist', 'polhead')
            set_color(target, 'setBackgroundColor', colors['panel'] if is_list else colors['background'])
            set_color(target, 'setForegroundColor', colors['text'])
            if is_list:
                set_color(target, 'setBackgroundColorSelected', colors['selected'])
                set_color(target, 'setForegroundColorSelected', colors['selected_text'])
