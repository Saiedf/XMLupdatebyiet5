# -*- coding: utf-8 -*-
"""Satellite-only adapter to Enigma2 ServiceScan; no database/driver writes."""
from __future__ import absolute_import


class ScanError(ValueError):
    pass


def number(data, key, default, low, high):
    try:
        value = int(data.get(key, default))
    except (ValueError, TypeError, OverflowError):
        raise ScanError('Invalid value for %s' % key)
    if key in ('is_id', 't2mi_plp_id') and value == 4294967295:
        value = -1
    if not low <= value <= high:
        raise ScanError('%s must be between %d and %d' % (key, low, high))
    return value


def capability(nim, name):
    try:
        return bool(getattr(nim, name)())
    except Exception:
        return False


def features(factory, nim):
    p = factory()
    return {
        'mis': all(hasattr(p, k) for k in ('is_id', 'pls_mode', 'pls_code'))
               and capability(nim, 'isMultistream'),
        't2mi': all(hasattr(p, k) for k in ('t2mi_plp_id', 't2mi_pid'))
                and capability(nim, 'isT2MI')}


def build_transponder(data, position, factory, nim, checked=None):
    """XML units: frequency kHz, symbol rate symbols/s (no MHz rounding)."""
    p = factory()
    system = number(data, 'system', 0, 0, 1)
    supported = checked['supported'] if checked is not None else capability(nim, 'isSupported')
    if not supported:
        raise ScanError('Tuner is not supported by this image/driver.')
    try:
        compatible = (checked['systems'][system] if checked is not None else
                      nim.isCompatible('DVB-S2' if system else 'DVB-S'))
    except Exception:
        compatible = False
    if not compatible:
        raise ScanError('Tuner does not support the requested DVB-S/S2 system.')
    p.frequency = number(data, 'frequency', 0, 1, 99999999)
    p.symbol_rate = number(data, 'symbol_rate', 0, 1, 99999999)
    p.polarisation = number(data, 'polarization', 0, 0, 3)
    p.fec = number(data, 'fec_inner', 0, 0, 15)
    if p.fec not in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15):
        raise ScanError('Unsupported FEC value.')
    p.inversion = number(data, 'inversion', 2, 0, 2)
    p.orbital_position = int(position) % 3600
    p.system = system
    p.modulation = number(data, 'modulation', 1, 0, 5)
    p.rolloff = number(data, 'rolloff', 0, 0, 3)
    p.pilot = number(data, 'pilot', 2, 0, 2)

    caps = checked['features'] if checked is not None else features(factory, nim)
    isi = number(data, 'is_id', -1, -1, 255)
    mode = number(data, 'pls_mode', 1, 0, 2)
    code = number(data, 'pls_code', 0, 0, 262142)
    # PLS can be used without an ISI filter.
    mis = isi != -1 or (mode, code) not in ((1, 0), (0, 1))
    plp = number(data, 't2mi_plp_id', -1, -1, 255)
    pid = number(data, 't2mi_pid', 4096, 0, 8191)
    if (mis or plp != -1) and not system:
        raise ScanError('MIS and satellite T2-MI require DVB-S2.')
    if mis and not caps['mis']:
        raise ScanError('MIS support is unavailable or unconfirmed on this tuner/image.')
    if plp != -1 and not caps['t2mi']:
        raise ScanError('Satellite T2-MI support is unavailable or unconfirmed on this tuner/image.')
    if hasattr(p, 'is_id'):
        p.is_id = isi if mis else getattr(p, 'No_Stream_Id_Filter', -1)
    if hasattr(p, 'pls_mode') and hasattr(p, 'pls_code'):
        mode_name = ('PLS_Root', 'PLS_Gold', 'PLS_Combo')[mode]
        if mis and not hasattr(p, mode_name):
            raise ScanError('The image does not expose %s.' % mode_name)
        p.pls_mode = getattr(p, mode_name) if mis else getattr(p, 'PLS_Gold', 1)
        p.pls_code = code if mis else getattr(p, 'PLS_Default_Gold_Code', 0)
    if hasattr(p, 't2mi_plp_id'):
        p.t2mi_plp_id = plp if plp != -1 else getattr(p, 'No_T2MI_PLP_Id', -1)
    if hasattr(p, 't2mi_pid'):
        p.t2mi_pid = pid if plp != -1 else getattr(p, 'T2MI_Default_Pid', 4096)
    return p


def make_scan(entries, position, factory, nim, manager):
    """Validate the entire batch before starting; never silently drop a stream."""
    if not entries:
        raise ScanError('No transponders to scan.')
    try:
        positions = [int(sat[0]) % 3600 for sat in manager.getSatListForNim(nim.slot)]
    except Exception:
        raise ScanError('Cannot verify the satellite configuration for this tuner.')
    if int(position) % 3600 not in positions:
        raise ScanError('Configure this satellite/LNB for the selected tuner first.')
    # Query native/driver capabilities once per batch, not once per stream.
    systems = {}
    for system, label in ((0, 'DVB-S'), (1, 'DVB-S2')):
        try:
            systems[system] = bool(nim.isCompatible(label))
        except Exception:
            systems[system] = False
    checked = {'supported': capability(nim, 'isSupported'),
               'systems': systems, 'features': features(factory, nim)}
    transponders = []
    seen = set()
    for index, data in enumerate(entries):
        try:
            p = build_transponder(data, position, factory, nim, checked)
        except (ValueError, TypeError, AttributeError, RuntimeError) as error:
            raise ScanError('Transponder %d: %s' % (index + 1, error))
        key = tuple(getattr(p, name, None) for name in (
            'frequency', 'symbol_rate', 'polarisation', 'fec', 'system',
            'modulation', 'inversion', 'rolloff', 'pilot', 'is_id',
            'pls_mode', 'pls_code', 't2mi_plp_id', 't2mi_pid'))
        if key not in seen:
            seen.add(key)
            transponders.append(p)
    # No remove-services, network-search or blind-discovery flags.
    return [{'transponders': transponders, 'feid': nim.slot, 'flags': 0}]
